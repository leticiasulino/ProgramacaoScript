package br.edu.fatecfranca.clientedb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClienteDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClienteDbApplication.class, args);
	}

}
